#include "Queue.h"
#include <string>
#include <iostream>

using namespace std;
//queue class for the member tohave 10 objects in it initially. 
Queue::Queue () {
  this->buffer = new string[10];
  this->currentSize = 10;
  this->head = 0;
  this->tail = 0;
  this->currentPeek = 0;
  this->capacity = 10;
}
Queue::Queue(int size){
  this->buffer = new string[size];
  this->currentSize = size;
  this->head = 0;
  this->tail = 0;
  this->currentPeek = 0;
  this->capacity = size;
}
//This moves the queue into another buffer when the old one gets full. Each time its gets more memory, double the size of the buffer. 
void Queue::add(string a){
  if (this->capacity >0) {
    if (this->tail <= this->currentSize) {
      this->buffer[tail]=a;
      this->tail++;
      this->capacity--;
    }
    else {
      this->growBufferIfNeccessary();
      this->buffer[tail]=a;
    }
  }
  else {
    throw "this queue is closed sorry";
  }
  
}
//The other member methods remove which is like pop
string Queue::remove () {
  string r = buffer[head];
  this->head++;
  return r;
}
//This returns the head of the queues without actually removing it.
string Queue::peek(){
  peekReset();
  return buffer[currentPeek];
}
//Puts the peekCurrent back to head, allows you to peek through the queue over and over 
void Queue::peekReset(){
  this->currentPeek = head;
}
//Return true if there is a next element to peek at, or false otherwise 
bool Queue::peekHasNext(){
  if(currentPeek+1<currentSize) {
    return true;
  }
  else { 
    return false;
  }
}
//returns the next element to be peeked at
string Queue::peekNext(){
  if(peekHasNext()){
    this->currentPeek+=1;
    return buffer[currentPeek];
  }
  else {
    return "";
  }
}