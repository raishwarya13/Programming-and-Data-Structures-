#include "Queue.h"
#include <iostream>
#include<string>
using namespace std;

int main () {
//sets the size to eight, this makes it so the people can add there names to the apple line
  int size = 8;
  Queue AppleLine (size);
  AppleLine.add ("Boris Karloff");
  AppleLine.add ("Bobby Shmurda");
  AppleLine.add ("Eric Johnson");
  AppleLine.add ("Zeke Torres");
  AppleLine.add ("Jean Luc");
//this keeps getting everyones names and counting the number of people in line, this does not chnage the population of the queue
  cout << "Line before me and my friends arrived" << endl;
  for (int i =0;i<size;i++) {
    if (i==0) {
      cout << AppleLine.peek() << endl;
      AppleLine.peekReset();
    }
    else {
      cout << AppleLine.peekNext()<<endl;
    }
  }
  //this calls the reset and adds people in line
  AppleLine.peekReset();

  AppleLine.add ("Jacob Goryance");
  AppleLine.add ("Daniel Ha");
  AppleLine.add ("Elliott Hoving");

  cout << "Line after me and my friends arrived" << endl;
  for (int i =0;i<size;i++) {
    if (i==0) {
      cout << AppleLine.peek() << endl;
      AppleLine.peekReset();
    }
    else {
      cout << AppleLine.peekNext()<<endl;
    }
  }
  AppleLine.peekReset();

  string firstInLine = AppleLine.peek();
//this closes the line and makes sure the people are still in line
  cout << "the line is now closed" << endl;
  for (int i =0;i < size;i++) {
    if (firstInLine == AppleLine.peek()) {
      cout << "clerk is relieved to see that " <<firstInLine << "is still first in line " << endl;
    }
    else {
      cout << "someone cut in line" << endl;
    }
  }
//this closes the queue 
  try {
    AppleLine.add ("new lad");
  }
  catch (exception& e) {
    cout << "this Queue is now closed"<< endl;
  }
  cout << "everyone gets their phone" << endl;
  for (int i =0;i < size;i++) {
    cout << AppleLine.remove() << " got their phone" << endl;
  }
//after the people get there things then the list becomes empty 
  cout << "Queue is now empty" << endl;

  cout << "completed to satisfaction" << endl;
}