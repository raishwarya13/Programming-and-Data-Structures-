#ifndef QUEUE_H
#define QUEUE_H 
#include <string>
using namespace std;

//This is a private member method which moves the queue into another buffer when the old one gets full. Each time that you need to get more memory, double the size of the buffer. Then deleted the old buffer once it finished copying it.
class Queue {
  private:
    string* buffer;
    int head,tail,capacity,currentSize,currentPeek;
    void growBufferIfNeccessary(){
      string *newBuffer = new string [(currentSize+1)];
      for (int i = 0; i < this->currentSize; i++){
        newBuffer[i] = buffer[(head + i) % this->currentSize];
      }
      this->currentSize++;
    }
  //creates the buffer to have room for 10 objects in it initially. 
  public:
    Queue();

     Queue(int);

     Queue(const Queue&);
    ~Queue(){
      delete[] buffer;
    }

    void add(string);

    string remove();

    string peek();

    void peekReset();

    bool peekHasNext();

    string peekNext();
    

  
};
#endif