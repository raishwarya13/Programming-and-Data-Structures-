/*
*Jacob G. Aishiwarya R. Yamin Y.
*10/10/2018
*This porgram is a use  of the recursive method mergeSort
*Outputs: the result of the mergesort to console
*/
#include <iostream>
#include<vector>

using namespace std;

vector <int> merge ( vector <int>& left, vector <int>& right, vector <int>& toReturn) {
  //creating a temp vector for the arrays to merge to
  vector <int> merged;

  //creating variables for later comparisons 
  int maxLeft = left.size();
  int maxRight =right.size();

  //creating variables to track the elements of each array to compare
  int rightctr=0;
  int leftctr =0;

  //creating a variable for the loop exit condition to occur once the arrays have been merged succesfully
  bool notDone=true;

  // a while loop to merge the elements
  while(notDone)  {

    //seeing if the indices of each element are valid
    if ( leftctr < maxLeft && rightctr < maxRight ){

      //comparing elements of each array to merge both if they are equal to each other
      if (left[leftctr] == right[rightctr]) {
        merged.push_back (left[leftctr]);
        merged.push_back (right[rightctr]);
        rightctr++;
        leftctr++;
      }//end if

      //else if to see if the left element at leftctr is less than the element of right at rightctr
      else if (left[leftctr] < right[rightctr]) {
        merged.push_back(left[leftctr]);
        leftctr++;
      }//end if 

      //else means that the element at rightctr is less than leftctr
      else {
        merged.push_back (right[rightctr]);
        rightctr++;
      }//end else

    }//end if

    //else if to check if the left array is out of elements to add, while adding right elements to merged
    else if (!(leftctr < maxLeft )&& rightctr < maxRight) {
      merged.push_back(right[rightctr]);
      rightctr++;
    }//end else if


    //else if to check if the right array is out of elements to add, while adding left elements to merged
    else if (leftctr < maxLeft && !(rightctr < maxRight )) {
      merged.push_back(left[leftctr]);
      leftctr++; 
    }//end if 

    //else determining that there are no more elements to merge, and loop needs to be exited
    else {
      notDone=false;
    }//end else 
    
  }//end while

  //assigning the values of the merged vector to the vector to return
  toReturn=merged;
  return toReturn;
}//end merge function





vector <int> mergeSort(vector <int>& toSort){

  //base case of the vector only having one element and being inherintly sorted
  if (toSort.size()==1) {
    return toSort;
  }//end if

    //variable to cut the vector in half into two vectors to then merge at the end of the function
    int mid = toSort.size()/2;

    //temp vector for the left half of the main vector
    vector <int> left;

    //for loop to populate the left vector
    for (int index =0; index < mid;index++) {
      left.push_back(toSort[index]);
    }//end for

    //a recursive call to sort the left vector
    mergeSort(left);
    
    //temp vector for the right half of the main vector
    vector <int> right; 

    //for loop to populate the right vector
    for (int index=mid; index < toSort.size(); index++) {
      right.push_back(toSort[index]);
    }//end for

    //a recursive call to sort the right vector
    mergeSort (right);


  //a call to merge the sorted arrays into the final sorted array and returning the sorted array
  return merge(left,right,toSort);

}//end mergeSort funciton



//main function to show the merge sort works
int main() {

  vector <int> one;
  one.push_back (73);
  one.push_back(9);
  one.push_back(10);
  one.push_back(21);
  one.push_back(37);
  one.push_back(34);
  one.push_back(59);
  one.push_back(56);
  one.push_back (8);



  cout << "unsorted array" << endl;
  for (int s=0;s<one.size();s++) {
    cout<< one[s]<< endl;
  }//end printing unsorted array for

  cout << endl << endl;

  mergeSort(one);

  cout << "now printing merge sorted array" << endl;
  for (int s=0;s<one.size();s++) {
    cout <<one[s]<< endl;
  
  }//end printing sorted array for


  cout << "completed to satisfaction" << endl;
  return 1;
}//end main function