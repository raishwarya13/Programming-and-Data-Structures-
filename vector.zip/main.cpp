/*
9/25/2018
Jacob G. Aishwarya R. Yamin Y.
Vector Lab
inputs: User prompts
Outputs: the vector values to console
*/

#include <iostream>
#include <string>
#include <vector>

using namespace std;

//This main function creates a displayVector which takes one parameter and loops around.
int main() {
  void displayVector (vector <string>);
  vector <string> labVector;
//This displays all the names in teh vector 
  labVector.push_back("Alice");
  labVector.push_back("Bob");
  labVector.push_back("Connie");
  labVector.push_back("David");
  labVector.push_back("Edward");
  labVector.push_back("Fran");
  labVector.push_back("Gomez");
  labVector.push_back("Harry");
  cout << "Task#1 " << endl;
  displayVector (labVector);

//This is the refernce to the iter which then is the refernce to the vector 
  vector <string>  :: iterator iter;
  string first = labVector.front(); //This is the first value of the vector
  string last = labVector.back(); //This is the last value of the vector 

//This displays task 2
  cout << "Task#2 " << endl;
  cout<< first << "\n" << last << endl; // this gets the first and last name in the array list
  cout << "Task#3" << endl;
  cout <<"size :" << labVector.size()<< endl;; //This prints the size of the array list
  cout << "Task#4"<< endl;
  //This for loop changges alice and alice b toklas 
  for ( string & name: labVector ) {
    if (name == "Alice") {
      name = "Alice B. Toklas";
    }
  }
  //This prints the array list to verify
  displayVector( labVector);
  
  cout << "Task#5" << endl;
  cout << "enter a name to insert doug after: "<< endl; //prompts the user for one of the names in the list
  //This accounts for the spaces in the name the user enters
  string input;
  getline(cin,input);
// this then inserts doug
  iter = labVector.begin();
    for ( string name: labVector ) {
    if (name == input) {
      labVector.insert(iter, "Doug");
    }
    iter++;
  }
  //this displays teh vector 
  displayVector (labVector);

  cout << "Task#6" <<endl;
  cout << "enter a name to delete: "<< endl; //prompts the user for a name to delete  
  //acounts for the spaces the user enters 
  getline(cin,input);
// this deletes the name in the vector 
  iter = labVector.begin();
    for ( string name: labVector ) {
    if (name == input) {
      labVector.erase(iter);
    }
    iter++;
  }
  //displays the new vector 
  displayVector (labVector);

  cout << "Task #7" << endl;
// This creates another vector and takes the name from before 
  vector <string> names2;
//this removes the first name in the first vector 
    for (string names:labVector){
    names2.push_back(names);
  }
    iter = labVector.begin();
    labVector.erase (iter);
    cout << "vector 1 " << endl;
    displayVector (labVector);
    cout << "vector 2"<< endl;
    // displays the new vector 
    displayVector (labVector);

}
// this prints out all the names in the vector 
void displayVector (vector<string> userVector){
  
  for (string s:userVector){
    cout << s << endl;
  }


}