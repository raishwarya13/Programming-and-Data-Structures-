#include "Dictionary.h"
#include<fstream>
#include<iostream>
#include<vector>
#include<string>
#include<algorithm>

using namespace std;

//initializes the dictionary function  
int Dictionary::initialize() {
  vector <string> temp;
//opens the dictionary file 
	ifstream fileIn("dictionary.txt");
	if (fileIn.fail()) {
		cout << "Failed to open file!\n";
		return -1;
	}
//reads through the txt file after opening 
	string nextword;
	int counter = 0;
	while (fileIn >> nextword) {
		temp.push_back(nextword);
		counter++;
	}
  vector <string> Dictionary::wordList = temp; 

	int Dictionary::wordListSize = counter;

	return counter;
}
//this is a helper function to the other locateStart function. It does all of the work, and is private. The arguments are  key, low, high, exat and returns.
int Dictionary::locateStart(string key, int low, int high, bool exact) {
	int keyLen = key.size();
	if (exact) {
		if (low <= high) {
			int mid = (low + high) / 2;

			if (Dictionary::wordList[mid].compare(key) > 0) {
				return locateStart(key, low, mid, exact);
			}
			else if (wordList[mid].compare(key) < 0) {
				return locateStart(key, mid, high, exact);
			}
			else if (wordList[mid].compare(key) == 0 && Dictionary::wordList[mid].size() == keyLen) {
				return mid;
			}
		}
		else {
			return -1;
		}
	 }
	else {
		if (low <= high) {
			int mid = (low + high) / 2;

			if ( wordList[mid].compare(key) > 0 ) {
				return locateStart ( key, low, mid, exact );
			}
			else if ( wordList[mid].compare(key) < 0 ) {
				return locateStart(key, mid, high, exact );
			}
			else if ( wordList[mid].compare(key) == 0 ) {
				return mid;
			}
		}
		else {
			return -1;
		}

	}
  return -1;
}
//when the static dictionary variable word list is empty, then it loads the words of the dictionary file onto it. Uses the intialize function to do so. Then returns the number of elements in the word list vector
int Dictionary::locateStart(string key, bool exact) {

	return locateStart(key, 0, wordListSize - 1, exact);

}