#include <vector>
#include <string>
#include <iostream>
#include "PartialSol.h"
#include "Dictionary.h"

using namespace std;
//Prompts the user for a string, unscramble it, and gives them all of the words that can be
made up entirely of that string, and nothing else
int main() {
	cout << "this program will unscramble an inputted string" << endl;

	while (true) {
		cout << "enter a string to unscramble or 'null' to exit" << endl;
		string yeet;
		cin >> yeet;
		if (yeet.compare("null") == 0) {
			break;
		}
		PartialSol toSolve("", yeet);
		vector <string> yeetus;
		toSolve.solvePartial(yeetus);
		for (int index = 0; index < yeetus.size(); index++) {
			cout << "solution: " << yeetus[index] << endl;
		}
	}
  //when its complete it prints out the completed statement 
	cout << "completed to satisfaction" << endl;

}