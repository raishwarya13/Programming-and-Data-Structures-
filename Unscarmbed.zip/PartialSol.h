#ifndef PARTIALSOL_H
#define PARTIALSOL_H
#include <string>
#include <vector>

using namespace std;

//This function creates teh member variables string unscrambled and string unused. Then creates static variables which are abandon, accept and contuine.
class PartialSol{
private:
	string unscrambled;
	string unused;
	static const int ABANDON = -1;
	static const int ACCEPT = 0;
	static const int CONTINUE = 1;
	

public:
	PartialSol(string unscrambled, string unused);

	vector <PartialSol> extend();

	int examine();

	void solvePartial(vector <string> &);
	string getUnscrambled();

};



#endif 