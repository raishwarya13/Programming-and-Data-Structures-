#include "PartialSol.h"
#include "Dictionary.h"
#include <string>
#include <vector>
#include <iostream>

PartialSol::PartialSol(string unscrambled, string unused) {
	this->unscrambled = unscrambled;
	this->unused = unused;

}
//starting with the PartialSolution that is the implicit parameter, generates a vector of PartialSolutions that are based on the unscrambled parameter of the implicit parameter PartialSolution. 
vector <PartialSol> PartialSol::extend() {
	vector <PartialSol> toReturn;
	for (int index = 0; index < this->unused.size() - 1; index++) {
		string newUnused;
		string newUnscramble;
		if (index > 0 && index <= this->unused.size()) {
			newUnused = unused.substr(0, index);
			newUnused += unused.substr(index + 1, this->unused.size());
		}
		else {
			newUnused = unused.substr(1, this->unused.size());
		}
		newUnscramble = this->unscrambled + unused.substr(index, index + 1);
		PartialSol newPartial(newUnscramble, newUnused);

		toReturn.push_back(newPartial);
	}
	return toReturn;
}
//Reviews the implicit parameter PartialSollution to see whether it is in the dictionary. If the implicit parameter PartialSolution has no unused characters, and the unscrambled member variable is a match in the dictionary, then returns PartialSolution::ACCEPT. If the same partial solution is not an exact match, then it returns PartialSolution::ABANDON. 
int PartialSol::examine() {
	bool exact;
	if (this->unused.size() > 0) {
		exact = true;
	}
	else {
		exact = false;
	}

	int test = Dictionary::locateStart(this->unscrambled, exact);
	if (test == 0 && exact) {
		return PartialSol::ACCEPT;
	}
	else if (test == 0) {
		return PartialSol::CONTINUE;
	}
	else {
		return PartialSol::ABANDON;
	}
}


string PartialSol::getUnscrambled() {
	return this->unscrambled;
}
//The vector input is a list of solutions in hand so far. This searches that to make sure that any solution that you come up with in solvePartial has not been found already.
void PartialSol::solvePartial(vector <string>& yeet) {
	int test = this->examine();
	if (test == this->ABANDON) {
		return;
	}
	else if (test == PartialSol::ACCEPT) {
		bool found = false;
		for (int index = 0; index < yeet.size(); index++) {
			if (yeet[index].compare( this->unscrambled) == 0) {
				found = true;
			}
		}
		if (!found) {
			yeet.push_back(this->getUnscrambled());
		}
	}
	else if (test == PartialSol::CONTINUE) {
		solvePartial(yeet);
	}

}