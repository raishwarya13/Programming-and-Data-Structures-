#ifndef DICTIONARY_H
#define DICTIONARY_H
#include <string>
#include <vector>

using namespace std;

class Dictionary {
private	

//This creates any instances of the dictionary class
public:
  static vector <string> wordList;//static member variable 
	static int wordListSize;//Instance memeber variable for word list size
	static int initialize();

	static int locateStart(string key, bool exact);

  static int locateStart(string key, int low, int high, bool exact);


};
#endif 