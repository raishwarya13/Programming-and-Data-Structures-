/*
 * BinaryTree.cpp
 *
 *  Created on: Jul 18, 2018
 *      Author: David 
 */

#include "BinaryTree.h"
#include <iostream>
using namespace std;

/**
 * Helper function used by insertNode.  The user never gets direct access to
 * the nodes within the binary tree, just the value of the nodes.  Note that
 * the arguments nodePtr and newNode are *&.  That allows us to update the
 * value of nodePtr.  If nodePtr is the head of the binary tree, and we are
 * inserting the first node, then this construct allows us to seamlessly
 * change the value of the binary tree's root pointer in this function.  A
 * similar consideration applies to the left and right pointers for the
 * various nodes.
 * @param	nodePtr	The pointer to the "current" node in the tree.  If this
 * 					is nullptr, then the new node goes right here.  Otherwise,
 * 					we keep looking for the spot in the tree.
 * @param	newNode	The pointer to the new node that you want to insert.
 */
void BinaryTree::insert(TreeNode *&nodePtr, TreeNode *&newNode)
{
	if (nodePtr == nullptr)
		nodePtr = newNode;                  // Insert the node.
	else if (newNode->value < nodePtr->value)
		insert(nodePtr->left, newNode);     // Search the left branch
	else
		insert(nodePtr->right, newNode);    // Search the right branch
}

/**
 * Add a new node to the binary tree to preserve the sort order.
 * This only works for strings at present, but we could easily have made
 * a template out of the TreeNode and then the binary tree could manage
 * nodes with any sort of value.
 * @param	item	The string that you want to add to the binary tree.
 */
void BinaryTree::insertNode(string item)
{
	TreeNode *newNode = nullptr;	// Pointer to a new node.

	// Create a new node and store item in it.
	newNode = new TreeNode;
	newNode->value = item;
	newNode->left = newNode->right = nullptr;

	// Insert the node.
	insert(root, newNode);
}

/**
 * Deallocate the space from this node down.  We need to essentially delete
 * the nodes from the bottom up since it is impossible to find the children
 * once the parent has been deleted.  Hence the recursive approach.
 * @param	nodePtr	Starting place for the deletion.
 */
void BinaryTree::destroySubTree(TreeNode *nodePtr)
{
	if (nodePtr)
	{
		if (nodePtr->left)
			destroySubTree(nodePtr->left);
		if (nodePtr->right)
			destroySubTree(nodePtr->right);
		delete nodePtr;
	}
}

/**
 * Look for a particular value in the tree and indicate whether that value exists
 * in the tree or not.  The == operator must be defined for whatever type you want
 * to store in the TreeNodes.
 * @param	item	The string value that you are searching for.
 * @return			True if we could find it, false otherwise.
 * @Note			We could have done this recursively, but iteratively works
 * 					just as well.
 */
bool BinaryTree::searchNode(string item)
{
	TreeNode *nodePtr = root;

	while (nodePtr)
	{
		if (nodePtr->value == item)
			return true;
		else if (item < nodePtr->value)
			nodePtr = nodePtr->left;
		else
			nodePtr = nodePtr->right;
	}
	return false;
}

/**
 * This is the public interface to the remove function.  Hunts down the first
 * node that it finds whose value == item and removes it.
 * @param	item	The value that you want to remove.
 */
void BinaryTree::remove(string item)
{
	deleteNode(item, root);
}

//********************************************
// deleteNode deletes the node whose value   *
// member is the same as num.                *
//********************************************
void BinaryTree::deleteNode(string item, TreeNode *&nodePtr)
{
	if (item < nodePtr->value)
		deleteNode(item, nodePtr->left);
	else if (item > nodePtr->value)
		deleteNode(item, nodePtr->right);
	else
		makeDeletion(nodePtr);
}

/**
 * Delete the pointed to node from the tree.
 * @param	nodePtr	Pointer to the node to be deleted.  Note that we will
 * 					change the value of that pointer.
 */
void BinaryTree::makeDeletion(TreeNode *&nodePtr)
{
	// Define a temporary pointer to use in reattaching
	// the left subtree.
	TreeNode *tempNodePtr = nullptr;

	if (nodePtr == nullptr)
		cout << "Cannot delete empty node.\n";
	else if (nodePtr->right == nullptr)
	{
		tempNodePtr = nodePtr;
		nodePtr = nodePtr->left;   // Reattach the left child
		delete tempNodePtr;
	}
	else if (nodePtr->left == nullptr)
	{
		tempNodePtr = nodePtr;
		nodePtr = nodePtr->right;  // Reattach the right child
		delete tempNodePtr;
	}
	// If the node has two children.
	else
	{
		// Move one node the right.
		tempNodePtr = nodePtr->right;
		// Go to the end left node.
		while (tempNodePtr->left)
			tempNodePtr = tempNodePtr->left;
		// Reattach the left subtree.
		tempNodePtr->left = nodePtr->left;
		tempNodePtr = nodePtr;
		// Reattach the right subtree.
		nodePtr = nodePtr->right;
		delete tempNodePtr;
	}
}

/**
 * Display the nodes of the tree in order, by whatever means < relationship
 * is established between two values of this type.  Note that this is a
 * helper function for the public displayInOrder() function.
 * @param	nodePtr	Starting place for the display.
 */
void BinaryTree::displayInOrder(TreeNode *nodePtr) const
{
	if (nodePtr)
	{
		displayInOrder(nodePtr->left);
		cout << nodePtr->value << endl;
		displayInOrder(nodePtr->right);
	}
}

/**
 * Display the nodes of the tree in pre order, by whatever means < relationship
 * is established between two values of this type.  Note that this is a
 * helper function for the public displayPreOrder() function.
 * @param	nodePtr	Starting place for the display.
 */
void BinaryTree::displayPreOrder(TreeNode *nodePtr) const
{
	if (nodePtr)
	{
		cout << nodePtr->value << endl;
		displayPreOrder(nodePtr->left);
		displayPreOrder(nodePtr->right);
	}
}

/**
 * Display the nodes of the tree in post order, by whatever means < relationship
 * is established between two values of this type.  Note that this is a
 * helper function for the public displayPostOrder() function.
 * @param	nodePtr	Starting place for the display.
 */
void BinaryTree::displayPostOrder(TreeNode *nodePtr) const
{
	if (nodePtr)
	{
		displayPostOrder(nodePtr->left);
		displayPostOrder(nodePtr->right);
		cout << nodePtr->value << endl;
	}
}
//Public method, this returns the number of nodes from the root of the binary tree to the leaf along the longest path
int BinaryTree::getHeight(){
  return getHeight(root);
}

//This returns the nodes at the level with teh most nodes. Uses the getHeight to find the height of the tree. Goes into a loop, getting the width of the tree at the next level starting at theroot and going to the lowest leaf and then returns maxWidth
int BinaryTree::getMaxWidth(){
  int height = getHeight();
  int maxwidth = 0;
  for(int i=1;i<=height;i++){
    int maxLevel = getWidth(this->root, i);
    if(maxLevel>maxwidth) {
      maxwidth=maxLevel;
    }
  }
  return maxwidth;
}

//This is a A TreeNode pointer where the function startsin the binary tree. This finds the height at any particular point in the tree by returning the maximum of the height of the left branch and the height of the right branch and adding one to it to account for the current node. Then returns the number of nodes from the given TreeNode down to the leaf node along the longest path
int BinaryTree::getHeight(TreeNode *nodePtr){
  if (nodePtr==NULL)  
       return 0; 
   else 
   { 
       /* compute the depth of each subtree */
       int lDepth = getHeight(nodePtr->left); 
       int rDepth = getHeight(nodePtr->right); 
  
       /* use the larger one */
       if (lDepth > rDepth)  
           return(lDepth+1); 
       else return(rDepth+1); 
   }

   
   
}
//This is a private method tree node in the binary tree where the getWidth algotithm starts. The number of levels down from the nodeptr. This returns the width of the tree below the given node, at the given number of levels down. The  number of levels to go down when finding the width. 
int BinaryTree::getWidth(TreeNode *nodePtr, int level){

     if(nodePtr == NULL) 
        return 0;
       
      if(level == 1) 
        return 1; 
              
      else 
        return getWidth(root->left, level-1) +  getWidth(root->right, level-1); 
   }
//Public method returns the total number of nodes in the entire tree. This just turns around and passes thae root of the binary tree to the countNodes function that takes a nodePtr pointer. 
int BinaryTree::countNodes () {
  return countNodes (this->root);
}
//Private method where a treeNoe pointer that is where we start the counting in the binary tree and returns the total number of nodes in  the tree below the nodePtr as well as the modePtr node itsef. This simply returns 1 + the count of the nodes under the left hand branch + the count of the nodes under the right hand branch of the tree
int BinaryTree::countNodes (TreeNode * nodeptr) {
  if (nodeptr != nullptr) {
    return (1 + (countNodes(nodeptr->left)) + (countNodes(nodeptr->left)));
  }
  else {
    return 0;
  }
}
