/*
 * BinaryTree.h
 *
 *  Created on: Jul 18, 2018
 *      Author: David
 */

#ifndef BINARYTREE_H_
#define BINARYTREE_H_

#include <iostream>
#include <string>
using namespace std;

class BinaryTree
{
private:
   struct TreeNode
   {
      string value;           // The value in the node
      TreeNode *left;    // Pointer to left child node
      TreeNode *right;   // Pointer to right child node
   };

   TreeNode *root;       // Pointer to the root node

   // Private member functions
   void insert(TreeNode *&, TreeNode *&);
   void destroySubTree(TreeNode *);
   void deleteNode(string, TreeNode *&);
   void makeDeletion(TreeNode *&);
   void displayInOrder(TreeNode *) const;
   void displayPreOrder(TreeNode *) const;
   void displayPostOrder(TreeNode *) const;
   int getHeight(TreeNode *);
   int getWidth(TreeNode *,int );
   int countNodes (TreeNode *);

public:
   // Constructor
   BinaryTree()
      { root = nullptr; }

   // Destructor
   ~BinaryTree()
      { destroySubTree(root); }

   // Binary tree operations
   void insertNode(string);
   bool searchNode(string);
   void remove(string);

   void displayInOrder() const
      {  displayInOrder(root); }

   void displayPreOrder() const
      {  displayPreOrder(root); }

   void displayPostOrder() const
      {  displayPostOrder(root); }
    int getMaxWidth();
    int getHeight();
    int countNodes();
};

#endif /* BINARYTREE_H_ */
