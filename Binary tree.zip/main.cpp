/*
 * BinaryTree.cpp
 *
 *  Created on: Jul 18, 2018
 *      Author: Aishwarya and Jacob 
 */

#include <iostream>
#include "BinaryTree.h"

  using namespace std;

int main() {
  int height = 0;
  int width = 0;
  int nodes = 0;
  BinaryTree tree;
  tree.insertNode("Larry Doering");
  cout <<"after one insertion"<< endl;
  height = tree.getHeight();
  width = tree.getMaxWidth();
  nodes = tree.countNodes();
  cout << "height: " << height << endl;
  cout << "width: " << width << endl;
  cout << "nodes: " << nodes << endl;

  tree.insertNode("Grant Stoltz");
  tree.insertNode("Randy Kerdun");
  cout <<"after three insertions"<< endl; 
  height = tree.getHeight();
  width = tree.getMaxWidth();
  nodes = tree.countNodes();
  cout << "height: " << height << endl;
  cout << "width: " << width << endl;
  cout << "nodes: " << nodes << endl;

  tree.insertNode("Dennis Miller");
  tree.insertNode("Kerry Tomei");
  tree.insertNode("Nancy Reagan");
  tree.insertNode("Veronica Mars");
  tree.insertNode("Bianca Bjorn");
  cout <<"after eight insertions"<< endl;
  height = tree.getHeight();
  width = tree.getMaxWidth();
  nodes = tree.countNodes();
  cout << "height: " << height << endl;
  cout << "width: " << width << endl;
  cout << "nodes: " << nodes << endl;

  tree.insertNode("Francine Hoffman");
  tree.insertNode("Helene Black");
  tree.insertNode("Kooper Sloan");
  tree.insertNode("Monica Faber");
  tree.insertNode("Oprah Winnona");
  tree.insertNode("Paula Abdul");
  tree.insertNode("Sandra Day O'Connor");
  cout <<"after last insertion"<< endl;
  height = tree.getHeight();
  width = tree.getMaxWidth();
  nodes = tree.countNodes();
  cout << "height: " << height << endl;
  cout << "width: " << width << endl;
  cout << "nodes: " << nodes << endl;

  cout << "completed to satisfaction" << endl;  
}