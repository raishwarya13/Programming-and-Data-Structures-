/*
Jacob G, Ashiwarya R. Yamin Y.
11/6/2018
Main File for the SortPointers

outputs text to console.
*/
#include <iostream>
#include <string>
#include <stdio.h>
using namespace std;
class Person{
  private:
  string Lname,Fname;
  int heightF,heightI;

  public:
   Person(){
    this->Lname = "N/A";
    this->Fname = "N/A";
    this->heightF = 0;
    this->heightI = 0;
  }

  public:
   Person(string Lname,string Fname,int heightF,int heightI){
    this->Lname = Lname;
    this->Fname = Fname;
    this->heightF = heightF;
    this->heightI = heightI;
  }
  public:
    /*
    *@param
    *@return string first name 
    */
    string getFirstName(){
      return this->Fname;
    }
    /*
    *@param
    *@return string last name
    */
    string getLastName(){
      return this->Lname;
    }
    /*
    *@param
    *@return int height in feet
    */
    int getHeightFeet(){
      return this->heightF;
    }
    /*
    *@param
    *@return int height inches
    */
    int getHeightInches(){
      return this->heightI;
    }

    public:
      /*
      *@param
      *@return string representation of Person
      */
      string toString() {
        string toReturn="";
        toReturn += this->Fname+" "+this->Lname+" " + to_string(this->heightF)+ "'"+ to_string(this->heightI)+"''";
        return toReturn;
      }
      /*
    *@param
    *@return 
    */
      int compLName(Person p1){
        if(this->Lname > p1.Lname){
          return -1;
        }
        else if(this->Lname < p1.Lname){
          return 1;
        }
        else{
          return 0;
        }
      }
      /*
    *@param Person p1: the person to compare names with 
    *@return int: 1 if this> p1; 0 if equal; -1 if this<p1
    */
      int compFName(Person p1){
        if(this->Fname > p1.Fname){
          return -1;
        }
        else if(this->Fname < p1.Fname){
          return 1;
        }
        else{
          return 0;
        }
      }
      /*
    *@param Person p1: the person to compare names with 
    *@return int: 1 if this> p1; 0 if equal; -1 if this<p1
    */
      int compFullName(Person p1){
        int x = compLName(p1);
        if(x==0){
          x = compFName(p1);
          return x;
        }
        else{
          return x;
        }
      }
      /*
    *@param Person p1: the person to compare names with 
    *@return int: 1 if this> p1; 0 if equal; -1 if this<p1
    */
      int compHeight(Person p1){
        if(this->heightF > p1.heightF){
          return -1;
        }
        else if(this->heightF < p1.heightF){
          return 1;
        }
        else{
          if(this->heightI>p1.heightI){
            return -1;
          }
          else if(this->heightI>p1.heightI){
            return 1;
          }
          else{
            return 0;
          }
        }
      }
};
void swap(int a, int b,Person (&arr)[],Person* barr)
{
    *barr[a]=arr[b];
    *barr[b]=arr[a];
}

int partitionFull (Person arr[],Person *barr, int low, int high)
{
    Person pivot = arr[high];    // pivot
    int i = (low - 1);  // Index of smaller element
 
    for (int j = low; j <= high- 1; j++)
    {
        // If current element is smaller than or
        // equal to pivot
        if (arr[j].compFullName(pivot)  <= 0)
        {
            i++;    // increment index of smaller element
            swap(i,j,arr,barr);
        }
    }
    swap(i+1, high,arr, barr);
    return (i + 1);
}
 
/* The main function that implements QuickSort
 arr[] --> Array to be sorted,
 *barr--> Array of Pointers corresponding to the arr
  low  --> Starting index,
  high  --> Ending index 
*/
void quickSortFull(Person arr[], Person* barr, int low, int high)
{
    if (low < high)
    {
        /* pi is partitioning index, arr[p] is now
           at right place */
        int pi = partitionFull(arr,barr, low, high);
 
        // Separately sort elements before
        // partition and after partition
        quickSortFull(arr,barr, low, pi - 1);
        quickSortFull(arr,barr, pi + 1, high);
    }
}
int partitionL (Person arr[],Person *barr, int low, int high)
{
    Person pivot = arr[high];    // pivot
    int i = (low - 1);  // Index of smaller element
 
    for (int j = low; j <= high- 1; j++)
    {
        // If current element is smaller than or
        // equal to pivot
        if (arr[j].compLName(pivot)  <= 0)
        {
            i++;    // increment index of smaller element
            swap(i,j,arr,barr);
        }
    }
    swap(i+1, high,arr, barr);
    return (i + 1);
}
 
/* The main function that implements QuickSort
 arr[] --> Array to be sorted,
 *barr--> Array of Pointers corresponding to the arr
  low  --> Starting index,
  high  --> Ending index 
*/
void quickSortL(Person arr[], Person *barr, int low, int high)
{
    if (low < high)
    {
        /* pi is partitioning index, arr[p] is now
           at right place */
        int pi = partitionL(arr,barr, low, high);
 
        // Separately sort elements before
        // partition and after partition
        quickSortL(arr,barr, low, pi - 1);
        quickSortL(arr,barr, pi + 1, high);
    }
}
int partition (Person arr[],Person *barr, int low, int high)
{
    Person pivot = arr[high];    // pivot
    int i = (low - 1);  // Index of smaller element
 
    for (int j = low; j <= high- 1; j++)
    {
        // If current element is smaller than or
        // equal to pivot
        if (arr[j].compFName(pivot)  <= 0)
        {
            i++;    // increment index of smaller element
            swap(i,j,arr,barr);
        }
    }
    swap(i+1, high,arr, barr);
    return (i + 1);
}
 
/* The main function that implements QuickSort
 arr[] --> Array to be sorted,
 *barr--> Array of Pointers corresponding to the arr
  low  --> Starting index,
  high  --> Ending index 
*/
void quickSortF(Person arr[], Person *barr, int low, int high)
{
    if (low < high)
    {
        /* pi is partitioning index, arr[p] is now
           at right place */
        int pi = partitionF(arr,barr, low, high);
 
        // Separately sort elements before
        // partition and after partition
        quickSortF(arr,barr, low, pi - 1);
        quickSortF(arr,barr, pi + 1, high);
    }
}
int main () {

  Person arr [] = new Person [10];
  int high = 9;
  Person* barr = new Person [10];
  arr[0]= new Person ("Yerto", "Fankle",12,10);
  barr[0]=&arr[0];
  arr[1]= new Person ("Certo", "Trankle",12,10);
  barr[1]=&arr[1];
  arr[2]= new Person ("Derto", "Pankle",12,10);
  barr[2]=&arr[2];
  arr[3]= new Person ("Lerto", "Dankle",12,10);
  barr[3]=&arr[3];
  arr[4]= new Person ("Kerto", "Yankle",12,10);
  barr[4]=&arr[4];
  arr[5]= new Person ("Nerto", "Rankle",12,10);
  barr[5]=&arr[5];
  arr[6]= new Person ("Ferto", "Cankle",12,10);
  barr[6]=&arr[6];
  arr[7]= new Person ("Erto", "Ankle",12,10);
  barr[7]=&arr[7];
  arr[8]= new Person ("Herto", "Bankle",12,10);
  barr[8]=&arr[8];
  arr[9]= new Person ("Berto", "Jankle",12,10);
  barr[9]=&arr[9];

  
  cout <<"unsorted"<< endl;

  for (int i =0; i < high;i++) {
    cout << barr[i].toString() << endl;
  }

  cout <<"\nFull Name Sorted"<< endl;
  
  quicksortFull(arr,barr,0,high);
  for (int i =0; i < high;i++) {
    cout << *barr[i]).toString() << endl;
  }
  cout <<"\nFirst Name Sorted"<< endl;
  quicksortF(arr,barr,0,high);
  for (int i =0; i < high;i++) {
    cout << *barr[i].toString() << endl;
  }

  cout <<"\nLast Name Sorted"<< endl;
  quicksortL(arr,barr,0,high);
  for (int i =0; i < high;i++) {
    cout << *barr[i].toString() << endl;
  }






  cout << "\ncompleted satisfactorily"<< endl;
  return 1;
}