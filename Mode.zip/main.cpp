/*
*Jacob G. Aishwarya R. Yamin Y.
*10/10/2018
*This porgram use an array of values of frequency and finds the mode in the array.  
*/
#include <vector> 
#include <iostream>

using namespace std;

//This is a structure called freq that has two member varaibles.
//the value is the vaue found in the list of values 
//The frequency is the number of times that value showed up in the array.
struct freq
{
	int value;
	int nValues;
};
  vector <freq>  findFreq(freq toFind, vector <freq> list) {
    bool noChange = true;
    for ( int index =0; index < list.size(); index++) {
      if ( toFind.value == list[index].value) {
        list[index].nValues += 1;
        noChange = false;
      }
    }
    if(noChange) {
      list.push_back(toFind);
    }
    return list;
  }
//Find freq is a function that locates a frew instnce in a list of freqs that matches on the value. 
vector <freq> mode(int * list, int listSize) {
	vector <freq> finalModes;
  for ( int index = 0; index < listSize; index++ ) {
    freq temp;
    temp.value = *list;
    temp.nValues = 1;
    finalModes = findFreq ( temp, finalModes);
    list++;
  }// end for loop
  return finalModes;
}
//sets the max and min the user can enter
 int main() {
   const int max = 100;
   const int min = 0;  
//makes sure that the user has entered an valid integer
	int userInput;
	cout << "How many values: ";
	cin >> userInput;
	while (userInput > max || userInput < min) {
		cout << "Error! number should range in " << max << " and " << min;
		cout << "Enter the number again:";
		cin >> userInput;
	}
//makes sure that the value in the range 
	cout << userInput << endl;
	int arr [100];
	for (int j = 0; j < userInput; j++) {
		cout << "Enter the next value=>";
		cin >> arr[j];
		cout << arr[j] << endl;
	}
//if the mode is not met with a tie then it returns the mode otherwise it takes in both values and stores it and returns 
	int *arrPointer = arr;
	vector <freq> toPrint;
  toPrint = mode(arrPointer, userInput); 
  bool tie = false;
  int tieIndex =0;
  freq temp;
	for (int index =1; index < toPrint.size(); index++) {
    temp = toPrint[0];
    if ( temp.nValues == toPrint[index].nValues ) {
      freq newPrint = toPrint[index];
      tieIndex = index;
      tie = true;
    }
    else if ( temp.nValues < toPrint[index].nValues ) {
      temp =toPrint[index];
    }
	}

//prints out the values needed as a result 
  cout << "arrValue / TimesOccurred == " << temp.value << " / " << temp.nValues << endl; 
  if (tie && temp.nValues == toPrint[tieIndex].nValues) {

    cout << "arrValue / TimesOccurred == " << toPrint[tieIndex].value << " / " <<  toPrint[tieIndex].nValues << endl; 
  }

  return 1;
}