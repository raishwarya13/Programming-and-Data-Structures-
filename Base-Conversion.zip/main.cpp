//============================================================================
// Name        : base_conversion.cpp
// Author      : Jacob, Yamin & Aishwarya 
// Version     : 1.00
// Description : Recursion demo program.  Meant to be worked with the class.
//============================================================================

#include <iostream>
#include <string>
#include <sstream>
#include <cstring>
using namespace std;
/**
 * Prompt the user for an integer within a range.
 * @param	min		The minimum allowable value.
 * @param	max		The maximum allowable value.
 * @return			The entered value.
 */
long long int getInt (int min, long long int max) {
	long int value;					//The prompted for menu option value.
	string str_number;				//String that the user inputs
	while(true) {
		cout << "Please enter a value between " << min << " and " << max << ": ";
		getline(cin, str_number);	//Get the user's input
		//Convert the input character string to a stringstream
		stringstream convert(str_number);
		//check for conversion success and between min/max
		if (convert >> value && !(convert >> str_number) &&
			value >= min && value <= max) return value;
		cin.clear();				//just in case we got an eof()
		cout <<"Error, input not in range." << endl;
	}
}
/**
 * Convert decimal integer to a string representation of that same number
 * in any base from 16 to 2.  This is a helper function to the newBase
 * that only has two input arguments.
 * @param		decimal	The decimal number to convert to another base.
 * @param		base	The base to convert to.
 * @return				The string representation of the number in the new base.
 */
string newBase (unsigned long long int decimal, unsigned int base) {
  const string DIGITS = "0123456789ABCDEF"; // give the string 
  unsigned long long int next = decimal / base;//next value
  if(next == 0){
    return DIGITS.substr(decimal,1);
  }
  else {
    string nextDigit = DIGITS.substr(decimal % base, 1);
    string rest = newBase( next , base );//pass in smaller valuer rather than origional value
    return rest.append(nextDigit);
  } 

  } ////end of the function
/*
 * Base conversion public function.  This one doesn't have to worry about the
 * sign.
 * @param		decimal	The decimal number to convert to another base.
 * @param		base	The base to convert to.
 * @return				The string representation of the number in the new base.
 */
string newBase (long long int decimal, unsigned int base) {
	unsigned long long int unsignDec;
	if (decimal < 0) {
		unsignDec = -decimal;
		string sign = "-";
		return sign.append(newBase(unsignDec, base));
	} else {
		unsignDec = decimal;
		return newBase (unsignDec, base);
	}
}
/**
 * Checks a string to see whether all of the digits are in the base.  For instance,
 * a supposedly base 3 number could not have any digits that are 3 or above.
 * @param	number	The string of digits to be checked.
 * @param	base	The base that the number is supposed to have.
 * @return	Boolean to tell whether or not it passed.
 */
bool numCheck (string number, unsigned int base) {
	if (number.size() < 1) {
		return false;
	} else {
		//list of all of the valid digits for base 16
		const string DIGITS = "0123456789ABCDEF";
		for (unsigned int i = 0; i < number.size(); i++){
			//look to see which digit this is
			unsigned int digit = DIGITS.find(number.c_str()[i],0);
			//check to make sure that it's a valid digit for the base
			if (digit == string::npos || digit >= base) {
				return false;		//bad digit
			}
		}
		return true;
	}
}
/**
 * Prompts the user for a new number and validates the individual digits.
 * @param	base	The base of the number (must be between 2 & 16 inclusive.
 * @return	A string representation of a number of that base.
 */
string newNumber (int base) {
	cout << "Please enter a base " << base << " number: ";
	string returnValue;
	getline (cin, returnValue, '\r');
	cin.ignore();					//skip the trailing \n
	while (!numCheck(returnValue, base)) {
		cout << "Error, " << returnValue << " is not a valid base " << base
			 << " value.  Try again: ";
		getline (cin, returnValue, '\r');
		cin.ignore();
	}
	return returnValue;
}
/**
 * Helper function to convert from any base back to decimal.
 * @param	number	The string representation of the number.
 * @param	base	The base of the number, between 2 & 16 inclusive.
 * @return			The decimal equivalent.
 */
long long int getDecimal (string number, int base, unsigned int digits) {
	//your code here
}
/**
 * Convert from any base back to decimal.
 * @param	number	The string representation of the number.
 * @param	base	The base of the number, between 2 & 16.
 * @return			The decimal equivalent.
 */
long long int getDecimal (string number, int base) {
	return getDecimal (number, base, number.length());
}
int main() {
	const long long int MAX_INT = 1000000000;
	cout << "Please enter the number to convert: ";
	long long int decimal = getInt (0, MAX_INT);
	do {
		if (decimal > 0) {
			cout << "Please enter the base to convert to: ";
			unsigned int base = getInt (2, 16);
			cout << "Decimal: " << decimal << " in base: " << base
				 << " is: " << newBase(decimal, base) << endl;
			cout << "Please enter the number to convert or 0 to exit." << endl;
			decimal = getInt (0, MAX_INT);
		}
	} while (decimal > 0);
	cout << "Please enter a base for the first number to convert to base 10: ";
	unsigned int base = getInt (2, 16);
	cout << "Please enter a number to convert to base 10 or 0 to exit: ";
	string number = newNumber(base);
	while (number != "0") {
		cout << "Decimal equivalent of " << number << " base " << base
			 << " is " << getDecimal(number, base) << " in decimal." << endl;
		cout << "Please enter a base for the next number to convert to base 10: ";
		base = getInt (2, 16);
		cout << "Please enter a number to convert from base " << base
			 << " to base 10 or 0 to exit: ";
		number = newNumber(base);
	}
	cout << "Completed Satisfactorily" << endl;
	return 0;
}