/*
*Jacob G. Aishwarya R. Yamin Y.
*10/18/2018
*This porgram used to build an application with aggregation.
*Outputs: The result of the vending machine 
*/

// This creates the header files, some are private and some are public 
#ifndef SODA_H
#define SODA_H
#include <string>
using namespace std;
class soda
{
  private:
  string name;
  int quantity;
  double value;

  public: 
  soda (string,int);
  soda ();

  string getName ();
  int getQuantity();
  void changeQuantity(int delta);

  string toString();
};
#endif
