/*
*Jacob G. Aishwarya R. Yamin Y.
*10/18/2018
*This porgram used to build an application with aggregation.
*Outputs: The result of the vending machine 
*/

#ifndef VENDINGMACHINE_H
#define VENDINGMACHINE_H
#include "soda.h"
#include <string>
#include <vector>

//Mamber varaibles, inventory which is a vector of soda and token count which is the amont of money that the given vending machine has accumalted. 
using namespace std;
class vendingMachine
  {
    private:
    string localDescription;
    vector <soda> inventory;
    int tokenCount;

    public:
    vendingMachine ();
    vendingMachine (string);

    bool vend (soda);
    void stock (soda);
    string toString();
  };
#endif
