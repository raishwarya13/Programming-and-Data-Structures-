/*
*Jacob G. Aishwarya R. Yamin Y.
*10/18/2018
*This porgram used to build an application with aggregation.
*Outputs: The result of the vending machine 
*/


#include "vendingMachine.h"
#include "soda.h"
#include <string>
#include <vector>
#include <iostream>


using namespace std;

//Requests soda that the customer wants to get from the vending machine. This captures the soda name and the number/
vendingMachine::vendingMachine () {
  this->localDescription ="N/A";
  this->tokenCount = 0;
}
vendingMachine::vendingMachine (string name) {
  this->localDescription = name;
  this->tokenCount = 0;
}

bool vendingMachine::vend (soda request) {
  string name = request.getName();
  int numSodas = request.getQuantity();

//Returns true if enough sodas of that type were found and false otherwise. The vend method has to remove the corresponding instance of the inventory of the vector a given execution of vend depletes. 
  int max = this->inventory.size();
  for (int index=0; index < max; index++) {
    if (inventory[index].getName().compare(name)==0) {
      if ( inventory[index].getQuantity() >= numSodas ) {
        this->inventory[index].changeQuantity(((-1)*(numSodas)));
        return true;
      }
    }
  }
  return false;
}
//To be added soda, one or more cans of a particular soda to add the inventory. If there are already some sodas of that name in the vending machine, just add to that instance of the Soda class in the inventory vector.

void vendingMachine::stock (soda toBeAdded) {
  int temp = this->inventory.size();
  if (!(temp==0)) {
    for (int index = 0; index < temp; index++) {
        if (toBeAdded.getName().compare(this->inventory[index].getName())==0) {
          this->inventory[index].changeQuantity(toBeAdded.getQuantity());
        }
        else {
         this->inventory.push_back(toBeAdded);
        }
      
    }
  }
  else {
   this->inventory.push_back(toBeAdded);
  }

}

//Returns a string, the location descripition inventory and the token count for the vending machine. Puts each soda of the inventory on its own line in the string output.
string vendingMachine::toString () {
  string toReturn ="";
  toReturn += "name: ";
  toReturn += this->localDescription;
  toReturn += "\ntotal inventory:\n";
  for (int index =0; index < this->inventory.size(); index++) {
    toReturn += (this->inventory[index].toString());
  }

  toReturn += "\ntokencount: ";
  toReturn += to_string(this ->tokenCount);
  toReturn += "\n";

  return toReturn;
}

