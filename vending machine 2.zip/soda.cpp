/*
*Jacob G. Aishwarya R. Yamin Y.
*10/18/2018
*This porgram used to build an application with aggregation.
*Outputs: The result of the vending machine 
*/

//This instances all the differnet files
#include "soda.h"
#include <string>
#include <iostream>

using namespace std;
//CHanges the soda structure to class. Reoves the price memeber variable and declares the member variables name and quantity. 
soda::soda (string name, int quantity) {
  this->name=name;
  this->quantity=quantity;
  this->value=0;
}
//Constructors, creates an instance of soda with quantity zero
soda::soda () {
  this->name ="";
  this->quantity=0;
  this->value=0.0;
}
//These are getters for getNamea and getQuantity 
string soda::getName () {
  return this->name;
}
int soda::getQuantity () {
  return this->quantity;
}
void soda::changeQuantity ( int delta) {
    this->quantity += delta;
}
//Creates a string representation of the info in the soda object
string soda::toString () {
  string toReturn="";
  toReturn += name;
  toReturn += ": ";
  toReturn += to_string(quantity);
  toReturn += "\n";

  return toReturn;

}