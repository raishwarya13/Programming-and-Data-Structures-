/*
*Jacob G. Aishwarya R. Yamin Y.
*10/18/2018
*This porgram used to build an application with aggregation.
*Outputs: The result of the vending machine 
*/
//This instances all the differnet files 
#include "vendingMachine.h"
#include "soda.h"
#include <string>
#include <vector>
#include <iostream>



int main () {
//This creates a vending mahine instance 
  vendingMachine testMan = vendingMachine("PepsiVendor");
//This prompts the user for sodas to stock until they are done. Then it prints outs the vending machine each time the user adds a soda to the vending machine.
  while (true) {
    string name="";
    int quantity=0;
    double value=0;
    cout << "please enter the name of the soda you would like to add the the machine" << endl;
    cin >> name;
    cout << "please enter the amount of that soda to add to the machine" <<endl;
    cin >> quantity;
    soda toAdd = soda(name,quantity);
    testMan.stock(toAdd);
    cout << testMan.toString();
    cout << "if you are done stocking sodas input a '1'";
    int breaker =0;
    cin >> breaker;
    if (breaker==1) {
      break;
    } 
  }
//This promots the user for the sodas that they want to vend from that machine. Then it prints out the vending machine each after vend execution.
    while (true) {
    string name="";
    int quantity=0;
    double value=0;
    cout << "please enter the name of the soda you would like to get from the the machine" << endl;
    cin >> name;
    cout << "please enter the amount of that soda you would like to get from the machine" <<endl;
    cin >> quantity;
    soda toAdd = soda(name,quantity); 

    if (testMan.vend(toAdd)) {
      cout << testMan.toString();  
    }
    else {
      cout << "error" << endl;
      break;
    }
    int breaker=0;
    cout << "if you are done vending sodas enter a '1'" << endl;
    cin >> breaker;
    if (breaker == 1) {
      break;
    }
  }
  cout <<"\ncompleted satisfactorily" << endl;

  return 1;
}
