#include "soda.h"
#include <iostream>
#include <limits>
#include <iostream>
#include <string>

int getInt () {
  int max = 100;
  int min =0;
  int input;
  do {
   cout << "Please enter a value between " << min <<" and " << max << endl;
    cin.clear();
    cin.ignore (std::numeric_limits<int>::max(),'\n');
    cin >> input;
  } while (  cin.fail() || (input > max || input < min) );
  return input;
}

double getDouble () {
  double max = 1.5;
  double min =0.5;
  double input;
  do {
   cout << "Please enter a value between " << min <<" and " << max << endl;
    cin.clear();
    cin.ignore (std::numeric_limits<int>::max(),'\n');
    cin >> input;
  } while (  cin.fail() || (input > max || input < min) );
  return input;
}


int main() {


  string sodaName;
  cout<< "Enter the soda name" << endl;
  getline(cin, sodaName);
  double unitPrice;
  cout << "enter the price of the soda" << endl;
  unitPrice= getDouble(); 

  cout << "enter the total number of sodas" << endl;
  int quantity=getInt();

  cout << "enter the value of the sodas" << endl;
  double value = getDouble();
  
  cout << sodaName << endl;
  cout << unitPrice << endl;
  cout << quantity << endl;
  cout << value << endl;





  soda newSoda;
  newSoda = soda(sodaName, unitPrice, quantity, value);
  cout << newSoda.toString() << endl;


return 1;
}