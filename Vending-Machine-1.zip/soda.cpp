#include "soda.h"
#include <string>
#include <iostream>

using namespace std;

soda::soda (string name, double unitPrice, int quantity,double value) {
  this->name=name;
  this->unitPrice=unitPrice;
  this->quantity=quantity;
  this->value=value;
}
soda::soda () {
  this->name ="";
  this->unitPrice=0.0;
  this->quantity=0;
  this->value=0.0;
}

string soda::toString () {
  string toReturn="";
  toReturn += "name of soda: ";
  toReturn += name;
  toReturn += " Unit price: ";
  toReturn += unitPrice;
  toReturn += " total amount of sodas on hand: ";
  toReturn += quantity;
  toReturn += " total Worth: ";
  toReturn += ((unitPrice)*(quantity));
  return toReturn;

}
