#ifndef SODA_H
#define SODA_H
#include <string>
using namespace std;
struct soda
{
  string name;
  double unitPrice;
  int quantity;
  double value;

  soda (string,double,int,double);
  soda ();


  string toString();
};
#endif

