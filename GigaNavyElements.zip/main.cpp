/*
Jacob Goryane, Yamin yee
Sept 011, 2018
Purpose: this program is a bar chart creator for a population 
inputs: a population files name, given by the user, and subsequently the file
Outputs: a new file of a chart of the first population file 
*/
#include <iostream>
#include <fstream>
#include <cmath>
#include <string>

using namespace std;


int main() {

ifstream populationFile;//file to be input
string fileName;//file name 
ofstream populationBarChart;//output file

while (true) {
  cout << "enter the name of the file" << endl;
  cin >> fileName;

  populationFile.open(fileName);
  
  if (populationFile.fail()){
    cout << "file wont open ";
  }//end if to confirm the file is valid
  else {
    break;
  }//end else for if the file is valid
}//end while to confirm valid file input

populationBarChart.open ("populationChart.txt");

int population;//population count per year from input file
int year1;//year from input file
string chartLength = "";// asterisks to be written in the chart file


while (populationFile >> year1) {
	populationFile >> population;
  population = ceil(population/1000.0);
  
	
  for (int ctr = 0; ctr < (population); ctr ++) {
		chartLength += "*";
	}//end for loop to fill chartLength
  populationBarChart << year1 << ":" << chartLength << "\n";


}// end while to read input file and write to output file

populationFile.close();
populationBarChart.close ();
cout << "program finish";

return 0;
}//end main ()