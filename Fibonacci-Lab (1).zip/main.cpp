/*
Name        : Fibnacci 
Author      : Yamin Yee & Jacob Goryance  & Aishwarya Ravishankar 
Version     :
Copyright   : Your copyright notice
Description : A function for fibnacci numbers  
*/
#include <iostream>
#include <vector>
using namespace std;

//This declares all the variables 

int main() {
int fibIterative (int);
int fibRecursive (int, vector <int>&);

//This declares the vector 
int fibToFind =19;
vector <int> hits (fibToFind+1,0);
//This displays the number of times each value is hit
cout << "iterative:" << endl;
cout << "fibonacci number of: "<< fibToFind <<" = "<<fibRecursive (fibToFind,hits) << endl; 
//This just displays the comment before the value stated
cout << "recursive:" << endl;
cout << "fibonacci number of: "<< fibToFind <<" = "<<fibRecursive (fibToFind,hits) << endl; 

// This prints out the values it hits 
cout << "hits values:" << endl;
for (int index = 0; index < hits.size(); index++) {
  cout << index <<" hit " << hits[index]<< " Times"<< endl;
}//end for
return 0;
}//end main()


//this declares all the variable used in this function 
int fibIterative (int findFibNum) {
  int prevNum =0;
  int prevPrevNum =0;
  int fibNumReturn =0;
  int timesLooped =0;

  // this while loop calculates the fibonacci number, the amount of number it takes for the calculation of eeach fibonacci number growns fast
  while (timesLooped < findFibNum ) {
    if (fibNumReturn > 0) {
      prevPrevNum = prevNum;
      prevNum =fibNumReturn; 
      fibNumReturn = prevNum+prevPrevNum;
    }//end if
    else {
      fibNumReturn++;
    }//end else
    timesLooped++;
  }//end while loop

  return fibNumReturn;

}//end fibIterative





//This function prints out the values in hits so one can see how many times the recursive method ends up recalculation the  differnt fibonacci numbers in the way

int fibRecursive (int findFibNum, vector <int>&  hits) {

  //increments hits for each fib number calculated
  if (hits.size() > findFibNum) {
   hits [findFibNum]++;
  }//end if  

  //base case 1
  if ( findFibNum == 0) {
    return 0;
  }//end if
  //base case 0
  else if( findFibNum ==1) {
    return 1;
  }//end else
  //recursive portion
  else {
    return ( fibRecursive (findFibNum - 1, hits)+ fibRecursive (findFibNum - 2,hits ));
  }//end else

}//end fibRecursive