/*
Jacob G. Aishwarya R. Yamin Y.
9/26/18
purpose: to parse in a file and export out a changed file with user specified manipulations
inputs: user prompts and a text file
outputs: console text and a tet file 

*/
#include <iostream>
#include <fstream>
#include <string>

using namespace std;




int main() {
  // forward casting the methods so they will work in main ()
  int searchStringArrays (int length, string countryNames[], string toFind);
  void sortArrays (int length, string names[], string pop[], string area []);
  //creating all of the filestream components necessary and setting a limit on how many elements we can process
  ofstream outFile; 
  ifstream countryFile;
  string fileName;
  int arrayLimit = 100;

  // a while loop to parse a valid text file
  while (true)  {
    cout << "please input the file name" << endl;
    cin >> fileName;

    countryFile.open(fileName);

    if (countryFile.fail()) {
      cout << "file wont open ";
      cin.ignore(256, 'n');
    } //end if
    else {
      break;  
    }//end else
  }//end while

  // creating all of the arrays and an index to note the last position used in the array
  string countryNames [arrayLimit];
  string population [arrayLimit];
  string area [arrayLimit];
  int arrCTR=0;

// creating a loop counter to make sure that we dont go over the limit of the array
  int loopCTR=0;

  // while loop that parses in a cstring of the whole line of the text file
  while (countryFile.peek() != EOF || loopCTR == arrayLimit ) {
    char interim [256]; 
    countryFile.getline(interim,256);
    string toBeParsed = "";
    for (int y =0; y<256; y++) {
      toBeParsed += interim [y];  
    }//end for
    // x finds the pos of | so we know where the values are in the text
    int x = toBeParsed.find_first_of ("|");
  
    // add all elements before | as the value of the arrays.
    string countryName;
    countryName = toBeParsed.substr (0,x);
    toBeParsed = toBeParsed.substr(x+1);
    countryNames[arrCTR] = countryName;
    // add all elements before | as the value of the arrays.  
    string pop;      
    x = toBeParsed.find_first_of ("|");
    pop = toBeParsed.substr(0,x);
    population[arrCTR] = pop;
    // add all elements before | as the value of the arrays.
    string ar;
    toBeParsed = toBeParsed.substr(x+1);
    x = toBeParsed.find_first_of ("|");
    ar = toBeParsed.substr(0,x);
    area[arrCTR] = ar;

      arrCTR++;
    loopCTR++;

  }//end while 
//sort the array at the start sop if we need to search it, it will be possible
sortArrays (arrCTR, countryNames, population, area);



//this loop is the user prompts that follow the algorithms provided in the text prompts

bool exit = false;//an exit case  
  while(!exit){
    int input;//user input of menu selection
    cout<<"1 - Change an existing country\n";
    cout<<"2 - Add a new country\n";
    cout<<"3 - Delete a country\n";
    cout<<"4 - List the defined countries\n";
    cout<<"5 - GO home\n";
    cin >> input;
    switch(input){
     case 1: {
                // the temp strings will add the elements separated by a space so country names can contain spaces
                string temp;
                string temp2;
                cout << "enter the name of the country you wish to change" << endl;
                cin >> temp;
                getline (cin,temp2);
                temp+=temp2;

                //finds index of element to change
                int toChange = searchStringArrays ( arrCTR,countryNames, temp);

                //prompts to modify the element
                cout << "enter the name of the new country" << endl;
                cin >> temp;
                getline (cin, temp2);
                temp+=temp2;

                countryNames[toChange] = temp;

                cout << "enter the population of the new country" << endl;
                cin >> temp;

                population [toChange] = temp;

                cout << "enter the area of the country" << endl;
                cin >> temp;

                area [toChange] = temp;

                sortArrays (arrCTR, countryNames, population, area);
                break;}// end case 1
      case 2: {
                // the temp string account for spaces in the name
                string temp;
                string temp2;
                cout<<"enter the name of the country you would like to add" << endl;
                cin >> temp;
                getline(cin,temp2);
                temp+= temp2;

                // adds the new values to the end of the array
                countryNames[arrCTR] = temp;

              
                cout << "enter the population of the new country" << endl;
                cin >> temp;
                population [arrCTR] = temp;

                cout << "enter the area of the new country" <<
                endl;
                cin >> temp;
                area[arrCTR]= temp; 

                arrCTR++;//increments arrCTR so the next index spot is available
                sortArrays (arrCTR, countryNames, population, area);
                break;}//end case 2
      case 3: {
                //find country to delete
                cout<<"Enter country you want to delete: "<< endl;
                string name;
                string nameTemp;
                cin >> name;
                getline(cin, nameTemp);
                name += nameTemp;
                //find index of country to delete
                int oldVal =searchStringArrays ( arrCTR,countryNames, name);

               //show user the info of the deleted value
               cout<<"Population of "<<countryNames[oldVal]<<" is :"<<population[oldVal]<<" and size in sq miles is : "<<area[oldVal]<<endl;
               cout<<"GONE!\n";
               //shift each element after the deleted value down one
               for (int i = oldVal; i < arrCTR-1; i++){
               countryNames[i] = countryNames[i+1];
               population[i] = population[i+1];
               area[i] = area[i+1];
              }//end for
              arrCTR--;// decrement the length of the array

                break;}// end case 3
      case 4: {
                //prints out all the countries and their info
                cout<<"countries:" << endl;
                for (int i = 0; i < arrCTR; i++){
                cout<< countryNames[i]<<"\t" <<population[i]<<"\t"<<area[i]<<endl;
                } //end for
                break;}// end case 4
      case 5: {
                //this indicates the termination of the program, but not before creating the output text file
                cout<<"Bye"<<endl;
                //creating the output file
                outFile.open ("finalCountries.txt");
                // adding all of the elements that have value in the arrays to the output file, with the proper "|" between all elements
                int newLoopCTR = 0;
                while (newLoopCTR < arrCTR ) {
                  outFile << countryNames [newLoopCTR] << "|" << population [newLoopCTR] << "|" << area[newLoopCTR] << "|" << "\n";
                  newLoopCTR++;
                }//end while
                //closing the file
                outFile.close();  
                //validating the hard exit case              
                exit = true;
                break;}//end case 5
                //to make sure the switch input is valid
      default:cout<<"Error: Value not in range\n";
              cin.ignore(256, '\n');
               continue;
    }// end switch statement
    
  }// end while loop
  return 0;
}// end method main

// binSearch
int searchStringArrays (int length, string countryNames[], string toFind) {
    int low=0;// low as the temp low of the search
    int high =length-1;// high as the last inex value of the arr
    int mid =0;// mid to be calculated in loop
    while (low <= high) {
        mid = (low + high) / 2;// setting mid to middle of low and high
        // testing to see if value is below or above mid to then narrow down the array to find the exact position
        if (countryNames[mid].compare(toFind) < 0) {
            low = mid + 1;
        } else if (countryNames[mid].compare(toFind) > 0) {
            high = mid - 1;
        } else {
            return mid;
        }// end else
    }// end while

    return -1;
}// end searchStringArrays ()

void sortArrays ( int length, string names [], string pop [], string area[]) {
  //sorts the array alphabetically by comparing each value to the next until it is sorted completely
  bool foundError = false; //makes sure all the passes have completed and array is in order
  while (!foundError)
  foundError =true;
  for (int index = 0; index < length-1; index ++) {
    if ( (names [index].compare(names[index+1])) > 0 ) {

      string temp = names[index];
      names[index] = names[index+1];
      names [index+1]=temp;

      temp = pop[index];
      pop[index] = pop[index+1];
      pop[index+1]=temp;


      temp = area[index];
      area[index] = area[index+1];
      area[index+1]=temp;  
      foundError = false;    
    }// end if
  }// end for

}// end sortArrays()