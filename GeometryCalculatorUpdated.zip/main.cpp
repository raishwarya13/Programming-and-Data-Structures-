/*
Jacob Goryane, Yamin yee
Sept 09, 2018
Purpose: this program is a calculator for various geometric shapes.
Inputs: the user will input
-menu choices and values to calculate with
Outputs: User Prompts, and the results of each calculation, as well as a summary of the calculations upon exit of the program 
*/
#include <string>
#include <iostream>
#include <cstdlib>
#include <climits>
#include <iomanip>  

using namespace std;

double getDouble (string prompt) {
  double userDbl; //user entered double
  while (true){ 
    cout << prompt << endl;
    cin >> userDbl;
    cin.ignore(256,'\n');
    if (userDbl > 0.0){
      break;
    }
    cout << "please enter a positive number.\n";
  }
  return userDbl;
}//end getDouble


int getMenuOption (int min, int max) {
  int userChoice; //user picked menu option
  while (true){
    cout << "enter the number that corresponds with the object that you would like to calculate\n" <<
          "1. Cirlce (area)\n" <<
          "2. rectangle (area)\n" <<
          "3. Triangle (area)\n" <<
          "4. sphere (volume)\n" <<
          "5. Box (volume)\n" <<
          "6. Cylander (volume)\n" <<
          "7. Exit \n";
    cin >> userChoice ;       
    cin.ignore(256,'\n');
    if (userChoice < min || userChoice > max || cin.fail()) {
      cout << "please enter a valid option\n";
    }//end if
    else {
      break;
    }//end else
  }//end while 
  return userChoice;
}//end getMenuOption

int main() {
  //this whole section of variables are counters for how many times each option gets picked
  int circleCTR=0; 
  int rectCTR=0;
  int triCTR=0;
  int sphereCTR=0;
  int boxCTR=0;
  int cylanderCTR=0;
//this section is a running total of all the calculated values added up per item
  double circTotal=0.0;
  double rectTotal=0.0;
  double triTotal=0.0;
  double sphereTotal=0.0;
  double boxTotal=0.0;
  double cylanderTotal=0.0;

  while (true) {
    int menuPick = getMenuOption (1,7);

    if ( menuPick == 1){
      circleCTR ++;

      double radius = getDouble("please enter the radius of the circle.\n");
      double pi = getDouble("please enter the number pi to the decimal precision that you would like \n");

      double area = ((radius*radius)*pi);
      circTotal +=area;
      cout << "the area of the circle is " << area << "\n";
    }//end if


    else if (menuPick ==2 ) {
      rectCTR++;

      double length = getDouble("please enter the length of the rectangle\n");
     double width = getDouble("please enter the width of the rectangle\n");

      double area = length*width;
      rectTotal += area;
      cout << "the area of the rectangle is " << area << "\n";
    }//end else if


    else if (menuPick == 3) {
      triCTR++;
    
      double base = getDouble("please enter the base of the triangle\n");
      double height = getDouble("please enter the height of the triangle\n");

      double area = (base*height)/2.0;
      triTotal += area;
      cout << "the area of the triangle is " <<  area << "\n";
    }//end else if


    else if (menuPick == 4) {
      sphereCTR++;

      double radius = getDouble("please enter the radius of the circle.\n");
      double pi = getDouble("please enter the number pi to the decimal precision that you would like \n");

      double volume = (4.0*pi*radius)/3.0;
      sphereTotal += volume;
      cout << "the volume of the sphere is " << volume << "\n";
    }//end else if


    else if (menuPick == 5) {
      boxCTR++;

      double length = getDouble("please enter the length of the box\n");
      double width = getDouble("please enter the width of the box\n");
     double height = getDouble("please enter the height of the box\n");

      double volume = length*width*height;
      boxTotal += volume;

      cout << "the volume of the box is " << volume << "\n";
    }//end else if
    
    
    else if (menuPick == 6) {
      cylanderCTR++;

      double radius = getDouble("please enter the radius of the circle.\n");
      double pi = getDouble("please enter the number pi to the decimal precision that you would like \n");
     double height = getDouble("please enter the height of the cylander\n");

      double volume = (pi*radius*radius*height);
      cylanderTotal += volume;

     cout << "the volume of the cylander is " << volume << "\n";      
    }//end else if


    else {
      break;
    }//end else
  }
  cout << "circles:   \t" << circleCTR << "\t" << circTotal <<"\n" <<
          "rectangles:\t" << rectCTR << "\t" << rectTotal << "\n" <<
          "triangles: \t" << triCTR << "\t" << triTotal << "\n" <<
          "spheres:   \t" << sphereCTR << "\t" << sphereTotal <<"\n" <<
          "boxes:     \t" << boxCTR << "\t" << boxTotal << "\n" <<
          "cylanders: \t" << cylanderCTR << "\t" << cylanderTotal <<"\n";
  
  return 0;
}//end main()