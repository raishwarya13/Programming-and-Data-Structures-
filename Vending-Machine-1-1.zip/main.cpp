/*
*Jacob G. Aishwarya R. Yamin Y.
*10/11/2018
*This porgram vending machine uses vector of structures to operate and calcuate. 
*Outputs: The result of the program is takes in structures and calculates the worth 
*/

#include "soda.h"
#include <iostream>
#include <limits>
#include <iostream>
#include <string>

//This function prompts the user for the number of sodas using the min and max and then returns the value the user entered. Also tests the int to see if its valid.
int getInt () {
  int max = 100;
  int min =0;
  int input;
  do {
   cout << "Please enter a value between " << min <<" and " << max << endl;
    cin.clear();
    cin.ignore (std::numeric_limits<int>::max(),'\n');
    cin >> input;
  } while (  cin.fail() || (input > max || input < min) );
  return input;
}

//This is like the getInt function so it would allow template functions that allows one to write a single functions that deals with both intgers and double precision numbres. 
double getDouble () {
  double max = 1.5;
  double min =0.5;
  double input;
  do {
   cout << "Please enter a value between " << min <<" and " << max << endl;
    cin.clear();
    cin.ignore (std::numeric_limits<int>::max(),'\n');
    cin >> input;
  } while (  cin.fail() || (input > max || input < min) );
  return input;
}

//The main function loops each time and promts the user for soda name, price each and quantity. Also calls the get price and quantity function to make sure that the numbers entered are in between and valid.

int main() {
  string sodaName;
  cout<< "Enter the soda name" << endl;
  getline(cin, sodaName);
  double unitPrice;
  cout << "enter the price of the soda" << endl;
  unitPrice= getDouble(); 

  cout << "enter the total number of sodas" << endl;
  int quantity=getInt();

  cout << "enter the value of the sodas" << endl;
  double value = getDouble();
  
  cout << sodaName << endl;
  cout << unitPrice << endl;
  cout << quantity << endl;
  cout << value << endl;

//This reports out to the inventory using the to_string function
  soda newSoda;
  newSoda = soda(sodaName, unitPrice, quantity, value);
  cout << newSoda.toString() << endl;


return 1;
}