/*
*Jacob G. Aishwarya R. Yamin Y.
*10/11/2018
*This porgram vending machine uses vector of structures to operate and calcuate. 
*Outputs: The result of the program is takes in structures and calculates the worth 
*/


#include "soda.h"
#include <string>
#include <iostream>

using namespace std;

//all the vairables are instancized so it can be called later
soda::soda (string name, double unitPrice, int quantity,double value) {
  this->name=name;
  this->unitPrice=unitPrice;
  this->quantity=quantity;
  this->value=value;
}

soda::soda () {
  this->name ="";
  this->unitPrice=0.0;
  this->quantity=0;
  this->value=0.0;
}
//this function has all the information about the paprticular soda. Puts all three of the soda instance variables into the string that will return from to-string

string soda::toString () {
  string toReturn="";
  toReturn += "name of soda: ";
  toReturn += name;
  toReturn += " Unit price: ";
  toReturn += to_string(unitPrice);
  toReturn += " total amount of sodas on hand: ";
  toReturn += to_string(quantity);
  toReturn += " total Worth: ";
  toReturn += to_string(((unitPrice)*(quantity)));
  return toReturn;

}