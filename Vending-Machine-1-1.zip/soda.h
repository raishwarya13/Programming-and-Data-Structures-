/*
*Jacob G. Aishwarya R. Yamin Y.
*10/11/2018
*This porgram vending machine uses vector of structures to operate and calcuate. 
*Outputs: The result of the program is takes in structures and calculates the worth 
*/


//This is defining all the structures included in this lab
#ifndef SODA_H
#define SODA_H
#include <string>
using namespace std;

//The varaibles that are being instancezied are the name of the soda, unit price, quantity and the value that is calculated 
struct soda
{
  string name;
  double unitPrice;
  int quantity;
  double value;

  soda (string,double,int,double);
  soda ();

// this instances the method which gives the infomation baout the particular soda. 
  string toString();
};
#endif

