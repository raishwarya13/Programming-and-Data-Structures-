#include "Stack.h"

/*
Jacob G, Aishwarya R. 
11/29/2018
cpp file for String List
*/
#include <list>

using namespace std;
//these are the member methods
Stack::Stack () {
  list <char> temp;
 this->stackman = temp; 
}
//the push takes a single char and pushes it onta the stack while using the push_front
void Stack::push(char toAdd) {
  this->stackman.push_front(toAdd);
}
//the pop returns the topmost char from the stack and deletes it
char Stack::pop () {
  char toReturn = this->stackman.front();
  this->stackman.pop_front();
  return toReturn;
}
//the isEmpty returns the boolean true if the stack has no elements and false otherwise
bool Stack::isEmpty() {
  if (this->stackman.size() == 0){
    return true;
  }
  else {
    return false;
  }
}