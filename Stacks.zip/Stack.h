/*
Jacob G, Aishwarya R. 
11/29/2018
cpp file for String List
*/

#ifndef STACK_H
#define STACK_H
#include <list>
using namespace std;
//this builds the class stack and calls the push.pop and isEmpty
class Stack {
  private:
   list <char> stackman;
  public: 
  Stack ();
  void push (char);
  char pop ();
  bool isEmpty();

};
#endif