/*
Jacob G, Aishwarya R. 
11/29/2018
cpp file for String List
*/

#include <iostream>
#include "Stack.h"
#include <list>
#include <string>
#include <array>
using namespace std;

//This is a free function called validate that takes the text string that the user enters, and returns a boolean to say whether that string is valid or not.
bool validate (string test) {
  string openers = "([{/";
  string closers = ")]}\\";
  Stack toTest;
//tests all char wherein the openers are equal to the closers or otherwise 
  for (int index = 0; index < test.length(); index ++) {
    for (int ctr= 0; ctr < 4; ctr++){
     if (test[index] == openers[ctr]) {
        toTest.push(test[index]);
      }
      else if ( test[index] == closers[ctr]) {
       char temp = toTest.pop();
        toTest.push(temp);
        if (toTest.isEmpty() && temp != test[index]) {                    return false;
        }
        else {
          temp = toTest.pop();
        }
      }
    }   
  }
return toTest.isEmpty();
}


int main() {
//this prompts the user for a string to validate and prompts for the next string 
  while (true) {
    string input;
    cout << "enter a string that we will validate" << endl;
    cin >> input;
    if (input.empty()) {
      break;
    }
  //this validates if the string is valid or not 
    else {
      if (validate(input)) {
        cout << "this string is valid!" << endl;
      }
      else {
        cout << "this string is not valid, try again"<< endl;
      }
    }
  }
  cout << "completed" << endl;
}