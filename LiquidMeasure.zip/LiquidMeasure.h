/*
Jacob G, Ashiwarya R. Yamin Y.
11/6/2018
Header File for the LiquidMeasure
*/
#ifndef LIQUIDMEASURE_H
#define LIQUIDMEASURE_H
#include <string>

using namespace std;

class LiquidMeasure {
	
  private:
		static int totalInstances;
		int gallons;
		int quarts;
		int cups;
		int ounces;
		LiquidMeasure(int ounces);

	
  public:
		static int numInstances();
		LiquidMeasure(int gallons, int quarts, int cups, int ounces);
		~LiquidMeasure();
		int getOunces();
		void simplify();
		LiquidMeasure operator +(LiquidMeasure other);
		LiquidMeasure operator -(LiquidMeasure other);
		LiquidMeasure operator =(LiquidMeasure other);
		bool operator ==(LiquidMeasure other);
		bool operator <=(LiquidMeasure other);
		bool operator >=(LiquidMeasure other);
		bool operator >(LiquidMeasure other);
		bool operator <(LiquidMeasure other);
		operator double ();
		operator int ();
		static int getTotalInstances() {
      return LiquidMeasure::totalInstances;
    }
		string toString();

};
#endif