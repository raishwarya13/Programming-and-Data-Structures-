/*
Jacob G, Ashiwarya R. Yamin Y.
11/6/2018
Main File for the LiquidMeasure

outputs text to console.
*/
#include "LiquidMeasure.h"
#include <iostream>
#include <string>

using namespace std;

int main() {
  cout << "creating all of the cups" << endl;

	cout <<"none here " << LiquidMeasure::numInstances() << endl;
	LiquidMeasure can1(0, 3, 2, 0);
	cout << "can1 here " <<LiquidMeasure::numInstances() << endl;
	LiquidMeasure can2(0,2,3,0);
	cout << "can2 here " <<LiquidMeasure::numInstances() << endl;
	LiquidMeasure can3(0, 2, 3, 0);
	cout << "can3 here " <<LiquidMeasure::numInstances() << endl;
	LiquidMeasure can4(0, 2, 0, 0);
	cout << "can4 here " <<LiquidMeasure::numInstances() << endl;

  cout << "first trip: added to the pot" << endl;
	LiquidMeasure pot = (can1 + can2);

  pot = pot +can3;
  pot = pot + can4; 
  cout << "pot here " << endl;
	cout << pot.toString() << endl;

	cout << "second trip: added to the pot" << endl;
  pot = (pot + can1);
  pot = pot + can2;
  pot = pot + can3;
  pot = pot+can4;
  cout << "pot here " << endl;
  cout << pot.toString() << endl;

  cout << "last trip: added to the pot" << endl;
  pot = pot + LiquidMeasure (0,1,7,0);
  cout << "pot here " << endl;
  cout << pot.toString() << endl;

  cout << "totalInstances: " << LiquidMeasure::numInstances()<<endl;

}