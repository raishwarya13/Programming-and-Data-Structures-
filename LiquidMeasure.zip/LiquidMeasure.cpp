/*
Jacob G, Ashiwarya R. Yamin Y.
11/6/2018
cpp file for the LiquidMeasure
all function definitions are here
*/
#include <iostream>
#include <string>
#include "LiquidMeasure.h"

int LiquidMeasure::totalInstances;

/*
*Private constructor for LiquidMeasure
*@Param ounces: the ounces of the object
*/
LiquidMeasure::LiquidMeasure (int ounces) {
  this->gallons=0;
  this->quarts=0;
  this->cups=0;
	this->ounces = ounces;
}
/*
*constructor for LiquidMeasure
*@Param ounces: the gallons, quarts, cups, and ounces of the object
*/
LiquidMeasure::LiquidMeasure(int gallons, int quarts, int cups, int ounces) {
	this->gallons = gallons;
	this->quarts = quarts;
	this->cups = cups;
	this->ounces = ounces;
	LiquidMeasure::totalInstances++;
}


LiquidMeasure::~LiquidMeasure() {
}

/*
*A method to return the total ounces of the object
*@Return int the total amount of ounces in the object
*/
int LiquidMeasure::getOunces() {
	int total = 0;
	total += (this->gallons) * (128);
	total += (this->quarts) * (32);
	total += (this->cups) * (4);
	total += this->ounces;
	return total;
}
/*
*A method to simplify the obect in descending order, prioritizing the highest amount of gallons, and so forth
*/
void LiquidMeasure::simplify() {
	int nGallons;
	int nQuarts;
	int nCups;
	int nOunces;

	int temp = this->getOunces();

	nGallons = temp / 128;
	temp = temp % 128;
	
  nQuarts = temp / 32;
  temp = temp % 32;
	
  nCups = temp / 16;
  temp = temp % 16;
	
  nOunces = temp;

	this->gallons = nGallons;
	this->quarts = nQuarts;
	this->cups = nCups;
	this->ounces = nOunces;

}

/*
*Operator override +
*@Return new LiquidMeasure object which is the sum of two other LiquidMeasures
*/
LiquidMeasure LiquidMeasure::operator+(LiquidMeasure other) {
	int newTotal;
	newTotal = this->getOunces() + other.getOunces();
	
	LiquidMeasure toReturn = LiquidMeasure(newTotal);
	toReturn.simplify();
	return toReturn;
}
/*
*Operator override -
*@Return new LiquidMeasure object which is the difference of two other LiquidMeasures
*/
LiquidMeasure LiquidMeasure::operator-(LiquidMeasure other) {
	int newTotal;
	newTotal = this->getOunces() - other.getOunces();

	LiquidMeasure toReturn(newTotal);
	toReturn.simplify();
	return toReturn;
}
/*
*Operator override =
*@Return new LiquidMeasure object which is a copy of other LiquidMeasure
*/
LiquidMeasure  LiquidMeasure::operator=(LiquidMeasure other) {
	LiquidMeasure newMeasure(other.gallons, other.quarts, other.cups, other.ounces);
  this->gallons= other.gallons;
  this->quarts= other.quarts;
  this->cups =other.cups;
  this->ounces = other.ounces;
  
	return newMeasure;
}
/*
*Operator override ==
*@Return bool if LiquidMeasures are equal in ounce value
*/
bool LiquidMeasure::operator==(LiquidMeasure other) {
	return (this->getOunces() == other.getOunces());
}
/*
*Operator override <=
*@Return bool if LiquidMeasures are less than or equal in ounce value
*/
bool LiquidMeasure::operator<=(LiquidMeasure other) {
	return (this->getOunces() <= other.getOunces());
}
/*
*Operator override >=
*@Return bool if LiquidMeasures are greater than or equal in ounce value
*/
bool  LiquidMeasure::operator>=(LiquidMeasure other) {
	return (this->getOunces() >= other.getOunces());
}
/*
*Operator override >
*@Return bool if LiquidMeasures are greater than in ounce value
*/
bool LiquidMeasure::operator>(LiquidMeasure other) {
	return (this->getOunces() > other.getOunces());
}
/*
*Operator override <
*@Return bool if LiquidMeasures are less than in ounce value
*/
bool LiquidMeasure::operator<(LiquidMeasure other) {
	return (this->getOunces() < other.getOunces());
}

/*
*Operator override double
*@Return double the typecasted double of liquidMeasure
*/
LiquidMeasure::operator double() {
	double toReturn = this->getOunces();
	return (toReturn / 128);
}
/*
*Operator override int
*@Return int the typecasted int of liquidMeasure
*/
LiquidMeasure::operator int() {
	int toReturn = this->getOunces();
	return (toReturn / 128);
}
/*
*Method to return total instances of liquidMeasures
*@Return int the number of existing liquidMeasures
*/
int LiquidMeasure::numInstances() {
	return LiquidMeasure::totalInstances;
}
/*
*prints out liquidMeasure's info
*@Return string representation of LiquidMeasure
*/
string LiquidMeasure::toString() {
	string toReturn;
	toReturn = "gallons: " + to_string(this->gallons) + "\n";
	toReturn += "quarts: " + to_string(this->quarts) + "\n";
	toReturn += "cups: " + to_string(this->cups) + "\n";
	toReturn += "ounces: " + to_string(this->ounces) + "\n";
  return toReturn;
	
}