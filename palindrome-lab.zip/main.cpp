//============================================================================
// Name        : main.cpp
// Author      : Yamin Yee & Jacob Goryance & Aishwarya Ravishankar
// Copyright   : Your copyright notice
// Description : Palindrome
//============================================================================




#include <iostream>
#include<algorithm>
#include <string>
#include <locale>
#include <cstring>

using namespace std;

int main(){//main function 
//forward casting the methods
  bool isPalindrome ( string input);
  bool isPalindrome ( string input, int begin, int end);
  //user input to be stored 
  string input;
  // do while loop so that the user can input multiple palindromes
	do {

	cout << "Enter the next possible palindrome, or dont enter anything to exit the program" << endl;
  //getting the input
	getline ( cin, input); 
  //if and else for each case of ther being a palindrome, or not based on the method call
  if ( isPalindrome(input)) {
    cout << input << " is a palindrome!" << endl;
  }//end if
  else {
    cout << input << " is not a palindrome." << endl;
  }//end else
  } while ( input.size() > 0);//end do While

  cout << "completed satisfactorily!" << endl;
  return 0;
				
}// end main


bool isPalindrome (string input, int begin, int end ) {
  //checks to see if there is one or no characters left, and if so, it is a palindrome
  if ( begin >= end || end-begin ==1 || end-begin ==0) {
    return true;
  }//end if
  // checks for blanks or symbols, if so increments begin to account for it then passes the new string through the method
  else if (!isalpha(input[begin])) {
    begin ++;
    return isPalindrome (input, begin,end);
   }//end else if
   // checks for blanks or symbols, if so increments end to account for it, then passes the new string through the method
  else if ( !isalpha(input[end])) {
    end--;
    return isPalindrome (input, begin,end );
  }//end else if
  // checks to see if the first and last character are equal, if so, adjusts the length and parameters of the string, then passes it through to a new isPalindrome
  else if ( input[begin]==input[end]){
    return isPalindrome ( input.substr(begin+1,end-1), (begin), (end-2));
   }//end else if
   //base case returns false if all other conditions evaluate to false
  else{
  return false;
  }//end else
}// end isPalindrome helper mehtod

bool isPalindrome (string input) {
  int begin = 0;
  int end = input.size()-1;
  return isPalindrome (input, begin,end );
}//end isPalindrome 
