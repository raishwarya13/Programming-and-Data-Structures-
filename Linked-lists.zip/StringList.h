/*
Jacob G, Ashiwarya R. 
11/27/2018
Header file for String List
*/
#ifndef STRINGLIST_H
#define STRINGLIST_H
#include <string>
#include <vector>
using namespace std;
class StringList;
class StringList
{
	private:
		//Internal structure for the nodes in the list
		struct ListNode {
			string value;
			struct ListNode *next;
		};
		ListNode *head;			//Start of the list
	public:
		class SIterator;
		StringList() {
			head = nullptr;		//Initialize the head of the list
		}
    string reverse (ListNode*) const; 
		void appendNode(string);
		void deleteNode(string);
		string operator [] (int) const;
		string reverse () const;
		string to_string() const;
		int getCount () const;
		~StringList();
};

#endif