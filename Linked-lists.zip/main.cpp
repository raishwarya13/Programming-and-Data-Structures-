#include <iostream>
#include <string>
using namespace std;

int main() {
  std::cout << "Hello World!\n";
}
string errorCheck= "item " + 0;