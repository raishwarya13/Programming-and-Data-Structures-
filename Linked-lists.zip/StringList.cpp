/*
Jacob G, Ashiwarya R. 
11/27/2018
cpp file for String List
*/
#include "StringList.h"
#include <string>
#include <sstream>
#include <iostream>
using namespace std;

// Makes the link list in the array accessable 
string StringList::operator [] (int pos) const {
  ListNode *ptr = this->head;
  for (int index=0; index < pos; index++) {
    ptr = ptr->next; 
  }
  return ptr->value;
}
//The reverse function reverses the string list 
string StringList::reverse () const {
  ListNode *ptr = this->head;
  return reverse (ptr);
}
string StringList::reverse (ListNode *ptr) const {
  if (ptr->next == nullptr) {
    return ptr->value;
  }
  else {
    return ((reverse (ptr->next)) + ptr->value);
  }
}
//Returns the whole list after the append 
string StringList::to_string() const {
  ListNode *ptr = this->head;
  int count = 0;
  string toReturn = "";
  while (ptr != nullptr) {
    toReturn = toReturn + std::to_string(count);
    toReturn = toReturn + ": ";
    toReturn = toReturn + ptr->value;
    toReturn = toReturn + "\n";
    count ++;
  }

  return toReturn;
}
//The getcount returns the total amount in the list 
int StringList::getCount() const {
  ListNode *ptr = this->head;
  int count =0;
  while (ptr != nullptr) {
    count ++;
    ptr= ptr->next;

  }
  return count;
}

void StringList::appendNode(string newVal) {
	ListNode *newNode;
	ListNode *nodePtr;				//To move through the list
	newNode = new ListNode;			//Allocate space for new node
	newNode->value = newVal;
	newNode->next = nullptr;		//Signify that this is the last node
	if (head == nullptr) {
		head = newNode;				//list is empty, we just added the head
	} else {
		nodePtr = head;				//start at the front of the list
		while (nodePtr->next != nullptr) {	//work our way down the list
			nodePtr = nodePtr->next;
		}
		nodePtr->next = newNode;		//tack that to the end of the list
	}
}

void StringList::deleteNode (string oldValue) {
	ListNode *nodePtr = this->head;
	ListNode *previous = nullptr;		//Previous
	while (nodePtr != nullptr && nodePtr->value != oldValue) {
		previous = nodePtr;
		nodePtr = nodePtr->next;
	}
	if (nodePtr != nullptr) {			//We found it
		if (previous == nullptr) {		//first one is to be deleted
			this->head = nodePtr->next;
		} else {
			previous->next = nodePtr->next;
		}
		delete nodePtr;
	}
}