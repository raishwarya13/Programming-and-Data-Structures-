#include <string>
#include "Person.h"

// Consructor 
Person::Person(string lName, string fName, int age) {
	this->lName = lName;
	this->fName = fName;
	this->age = age;
	
}
//last name getter
string Person::getLName() {
	return this->lName;
}
//frist name getter
string Person::getFName() {
	return this->fName;
}
//age getter 
int Person::getAge() {
	return this->age;
}

//Comparing last name 
int Person::compareTolName(Person other) {
	int toCompare = this->lName.compare(other.getLName());
  if ( toCompare > 0) {
    return 1;
  }
  else if (toCompare < 0) {
    return -1;
  }
  else {
    return 0;
  }
}

//Comparing first name 
int Person::compareTofName(Person other) {
		int toCompare = this->fName.compare(other.getFName());
  if ( toCompare > 0) {
    return 1;
  }
  else if (toCompare < 0) {
    return -1;
  }
  else {
    return 0;
  }
}

//compare to age
int Person::compareToAge(Person other) {
	if (this->age == other.getAge()) {
		return 0;
	}
	else if (this->age < other.getAge()) {
		return -1;
	}
	else {
		return 1;
	}
}

// setting the pointer to different to differnet function 
void Person::setCompFunc(int(Person::* newCompFunc)(Person)){
	this->compFunc = newCompFunc;
}

// camparing the obj base on the method pointer reference 
int Person::compare(Person other) {
	
	return (this->*compFunc)(other);
}