#ifndef PERSON_H
#define PERSON_H
#include <string>
using namespace std;

//Building the person object 
class Person
{
// The member variables are  last name, first name and age
private:
	string lName;
	string fName;
	int age;
	int (Person::*compFunc) (Person);

//the compFunc is a function pointer that will point to a person member function that returns an integer. 
//The int says that the function pointed must return an int
//The person tells  that it has to be one of the person class member functions
//compFunc is the name of the member variable that we use
//Person in parentheiss is like a function prototype
public:
	Person(string lName, string fName, int age);
	string getLName();
	string getFName();
	int getAge();
	int compareTolName(Person other);
	int compareTofName(Person other);
	int compareToAge(Person other);
	void setCompFunc(int(Person::*newCompFunc)(Person));
	int compare(Person other);

};

#endif // !PERSON_H