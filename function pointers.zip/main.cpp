#include "Person.h"
#include <iostream>
int main()	{
//first instance of person
Person MrZ = Person("Vladimere", "Zorov", 26);
//second instance of person
Person MrS = Person("Oscar", "Smith", 72);
//setting the pointer to compare the first Names
MrZ.setCompFunc(&Person::compareTofName);
cout << MrZ.compare(MrS) << endl; //1
//setting the pointer to compare the ages, then outputting the result;
MrS.setCompFunc(&Person::compareTolName);
cout << MrS.compare(MrS) << endl; //-1


cout << "completed to satisfaction" << endl;

return 0;
}