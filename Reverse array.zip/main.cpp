/*
Jacob G. Yamin Y. Aishiwarya R.
10/30/2018
CECS275

this program uses pointer arithmatic to reverse an array that is dynamically allocated then re-allocated, for later use.
*/
#include <iostream>
#include <string>


using namespace std;




//creating the reverse function
/*
@param int arr[]: the array to reverse;
@param int size: size of the arr;

reverse the array and return a pointer to a dynamically allocated arr, in reverse

@return a pointer to the reversed array.
*/
int* reverse( int arr [], int size) {
  //creating the pointer to return
	int * toReturn; 

  //dynamically allocating the array
	toReturn = new (nothrow) int[size];

  //populating dynamic array with the reverse of arr
	for (int index = 0; index < size; index++) {
		toReturn[index] = arr [(size-1)-index];
	}

  //returning pointer to new dynamic array
	return toReturn;
}



int main() {
  //creating a static arr
	static int yeetus [10];
  //populating the arr with unique numbers
	for (int index = 0; index < 10; index++) {
		yeetus[index] = (10 * index / 3) + 8;
	}
  //printing out the array
	cout << "array normal" << endl;
	for(int index = 0; index < 10; index++) {
		cout << yeetus[index] << endl;
	}

  //creating a pointer t0 the reverse arr
	int * schleet = reverse(yeetus, 10);
  //printing out the reverse arr
	cout << "reverse" << endl;
	for (int index = 0; index < 10; index++) {
      cout << schleet[index] << endl;
	}
  //deleting the storage for the array so memory can be re-allocated
  delete [] schleet;

	cout << "completed to satisfaction" << endl;
	return 1;
}