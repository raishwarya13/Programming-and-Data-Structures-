#include "IndexOutOfBoundsException.h"
#include <string>
using namespace std;
IndexOutOfBoundsException::IndexOutOfBoundsException(int offender, string message) 
//these are the index out of bounds exception class
{
  this->message = message;
  this->index = offender;
}

//These are the getters that are getIndex and get message
string IndexOutOfBoundsException:: getMessage() 
{
  return this->message;
}
int IndexOutOfBoundsException:: getIndex ()
{
  return this-> index;
}
