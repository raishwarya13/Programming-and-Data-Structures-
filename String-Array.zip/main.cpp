#include <iostream>
#include "bigString.h"
#include "IndexOutOfBoundsException.h"

using namespace std;

int main() 
{
// This adds 5 strings to the string arrray. Asfter eacg ass call, it writes out to the console how many elements are in the array and the size of the arrary
  bigString testBoy(5);
  testBoy.add("1st string");
  testBoy.add("2nd string");
  testBoy.add("3rd string");
  testBoy.add("4th string");
  testBoy.add("5th string");

//Goes into a loop and retrieve each elements in turn.
  for (int index = 0; index <= testBoy.getSize();index++) 
  {
    cout << testBoy[index] << endl;
  }
//Attempts to create a new string instance with room for -5 elements in it.
  bigString newTestBoy (-5);

  cout << "completed unsatisfactorily" << endl;
  
  return 1;
}