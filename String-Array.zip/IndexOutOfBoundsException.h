#pragma once 
#include <string>
using namespace std;
class IndexOutOfBoundsException 
{
//member variables 
  private:
    string message;
    int index;
//constructors with two parameters the offending index and the message
  public:
    IndexOutOfBoundsException(int offender, string message);
    string getMessage();
    int getIndex();
};