#pragma once
#include <string>
using namespace std;
class bigString
{
//member cariables which are all private 
private:
	int numElements;
	int size;
	string* arr;
	void resizeIfNeccesary();
	void deleter();

//constructors that are public 
public:
	bigString();
	bigString(int Elements);
	string operator [](int idx);
	void add(string toAdd);
	int getNumElements();
	int getSize();
};

