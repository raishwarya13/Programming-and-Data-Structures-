#include "bigString.h"
#include "IndexOutOfBoundsException.h"
#include <string>
#include <iostream>
using namespace std;

//if the number of elements already in the string then it goes to the size of the array 
void bigString::resizeIfNeccesary()
{
	string* newBoy = new string[(this->size*2)];
	for (int index = 0; index < this->size; index++) {
		*(newBoy + index) = *(arr + index);
		this->size *= 2;
	}
	this->arr = newBoy;

}
//copies all the values, delete the old array
void bigString::deleter()
{
	delete this->arr;
	delete this;
}
//sets the string pointer to the new arrary
bigString::bigString()
{
	this->size = 0;
	this->numElements = 0;
	this->arr = new string[0];
}
bigString::bigString(int Elements)
{
	this->size = Elements;
	this->arr = new string[Elements];
	this->numElements = 0;
}

// this is the operator overload 
string bigString::operator[](int idx)
{
	try {
		if (idx < 0 || idx >= size) {
			throw IndexOutOfBoundsException(idx,"index is out of bounds");
		}
      return arr[idx];
	}
	catch(IndexOutOfBoundsException e) {
    cout << e.getMessage() << " at "<< e.getIndex()<< endl;
		resizeIfNeccesary();
    return arr[idx];
	}
}
//adds a new element to the end of the string array.
void bigString::add(string toAdd)
{
  
	*(arr+this->numElements)= toAdd;
	numElements++;
}
//returns the number of elements already in the string array
int bigString::getNumElements()
{
	return this->numElements;
}

//returns the size of the array
int bigString::getSize()
{
	return this->size;
}


